package com.gqt.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Car {
	private String username;
	private String carModel;
	private String carType;
	private String carRegistrationNumber;
	private String serviceType;
	private String serviceRequest;
	Connection con = null;

	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public String getCarType() {
		return carType;
	}
	public void setCarType(String carType) {
		this.carType = carType;
	}
	public String getCarRegistrationNumber() {
		return carRegistrationNumber;
	}
	public void setCarRegistrationNumber(String carRegistrationNumber) {
		this.carRegistrationNumber = carRegistrationNumber;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getServiceRequest() {
		return serviceRequest;
	}
	public void setServiceRequest(String serviceRequest) {
		this.serviceRequest = serviceRequest;
	}
	public Car(String username, String carModel, String carType, String carRegistrationNumber, String serviceType,
			String serviceRequest) {
		super();
		this.username = username;
		this.carModel = carModel;
		this.carType = carType;
		this.carRegistrationNumber = carRegistrationNumber;
		this.serviceType = serviceType;
		this.serviceRequest = serviceRequest;
	}
	public Car() {
		super();
	}

	{
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system","root", "Bhav@123");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}	
	public int addCarDetails() {
		String s = "insert into car values(?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement pstmt = con.prepareStatement(s);
			pstmt.setString(1,  username);
			pstmt.setString(2,  carModel);
			pstmt.setString(3,  carType);
			pstmt.setString(4,  carRegistrationNumber);
			pstmt.setString(5,  "false");
			pstmt.setString(6,  "false");
			int rows = pstmt.executeUpdate();
			return rows;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int requestService() {
		// TODO Auto-generated method stub
		return 0;
	}
}