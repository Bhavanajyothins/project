package com.gqt.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Customer {
	private String name;
	private String username;
	private String email;
	private String password;
	Connection con = null;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Customer(String name, String username, String email, String password) {
		super();
		this.name = name;
		this.username = username;
		this.email = email;
		this.password = password;
	}
	public Customer() {
		super(); 
	}
	{
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_service_system","root","Bhav@123");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	public int customerRegister() {
		try {
			String s1 = "select * from customer where username=?";
			PreparedStatement pstmt1 = con.prepareStatement(s1);
			pstmt1.setString(1, username);
			ResultSet res = pstmt1.executeQuery();
			if(res.next()==true) {
				return -1;
			}

			String s = "insert into customer values(?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(s);
			pstmt.setString(1, name);
			pstmt.setString(2, username);
			pstmt.setString(3, email);
			pstmt.setString(4, password);

			int rows = pstmt.executeUpdate();
			return rows;
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int customerLogin() {
		try {
			String s1 = "select * from customer where username = ?";
			PreparedStatement pstmt1 = con.prepareStatement(s1);
			pstmt1.setString(1, username);
			ResultSet res = pstmt1.executeQuery();
			if(res.next()) {
				if(res.getString(4).equals(password)) {
					return 1; //login success
				}
				else {
					return 0; //invalid password
				}
			}
			else {
				return -1; //invalid username
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0; 
	}
}