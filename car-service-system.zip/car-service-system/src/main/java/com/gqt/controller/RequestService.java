import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.gqt.model.Car;


public class RequestService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type_of_service=request.getParameter("type_of_service");
		String car_reg_no=request.getParameter("car_reg_no");
		
		HttpSession session=request.getSession();
		String username=(String)session.getAttribute("susername");
		
		Car c=new Car();
		c.setUsername(username);
		c.setServiceType(type_of_service);
		c.setCarRegistrationNumber(car_reg_no);
		
		int rows=c.requestService();
		if(rows==0) {
			response.sendRedirect("/car-service-system/requestServiceFailure.jsp");
		}
		else {
			response.sendRedirect("/car-service-system/requestServiceSucess.jsp");
		}
			}
	}